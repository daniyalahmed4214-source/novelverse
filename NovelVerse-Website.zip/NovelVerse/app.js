// NovelVerse demo content. Replace these sample entries with books you have written permission to publish.
const books = [
  {id:"hidden-world",title:"The Hidden World",author:"Sample Author",category:"Fantasy",symbol:"✧",colors:["#554324","#171612"],description:"A curious traveller discovers a forgotten place beyond the edge of an ordinary map.",chapters:[
    {title:"The Map in the Attic",text:"The rain had stopped just before midnight. In the quiet house, Mira found a folded map tucked inside an old wooden book.\n\nThere were no street names, no familiar landmarks—only a small golden star drawn at the edge of a forest.\n\nAt the bottom, in handwriting she almost recognised, were five words: Some doors open only once.\n\nMira turned the map over. A new line appeared, ink-dark and shining, leading straight to the hills."},
    {title:"Beyond the Last Road",text:"At sunrise, Mira reached the last road marked on the map. Beyond it, the trees stood close together, their leaves silver with dew.\n\nShe took one careful step beneath the branches. Behind her, the road seemed to grow quieter, as if the world were holding its breath.\n\nThen a small lantern lit itself between the trees."},
    {title:"A Light in the Trees",text:"The lantern drifted forward without a hand to carry it. Mira followed at a distance, keeping the map open in her palm.\n\nA voice, gentle as a page turning, spoke from the shadows: “You found the beginning. Are you ready to read the rest?”"}
  ]},
  {id:"last-clue",title:"The Last Clue",author:"Sample Author",category:"Mystery",symbol:"⌕",colors:["#25333a","#111719"],description:"A quiet town, an unopened letter, and a mystery hiding in plain sight.",chapters:[
    {title:"The Unopened Letter",text:"The letter arrived on a Thursday, with no return address and a date from twenty years earlier.\n\nInside was a photograph of the town clock. Someone had circled one minute in red ink.\n\nOn the back, a single sentence waited: Look where the hour never changes."},
    {title:"The Clockmaker's Shop",text:"Dust covered the shelves of the old clockmaker's shop. Every clock had stopped at the same minute.\n\nNora held the photograph beside the largest clock. The red circle matched a tiny mark beneath its face.\n\nA drawer clicked open."}
  ]},
  {id:"blue-horizon",title:"The Blue Horizon",author:"Sample Author",category:"Adventure",symbol:"◈",colors:["#244454","#101b25"],description:"Two friends set out across the coast in search of a place from an old sailor's tale.",chapters:[
    {title:"The Departure",text:"The sea was calm when the little boat left the harbour. Ilyas checked the compass while Rowan unfolded the sailor's note.\n\nTheir destination was not marked on any modern chart. It was simply called the Blue Horizon."},
    {title:"The Far Shore",text:"By afternoon, the coastline had disappeared. A line of blue light shimmered far ahead, just above the water.\n\nNeither friend spoke. Some discoveries, they felt, deserved a quiet moment."}
  ]},
  {id:"letters-autumn",title:"Letters in Autumn",author:"Sample Author",category:"Romance",symbol:"❧",colors:["#68433c","#201513"],description:"A gentle, fictional story about friendship, letters, and the courage to begin again.",chapters:[
    {title:"A Note Between Pages",text:"A handwritten note slipped from the pages of a second-hand book. It was short, unsigned, and ended with a question: What would you do if you could start again?\n\nAmara smiled at the thought and reached for a pen."},
    {title:"The Reply",text:"The next week, the book was back on the same shelf. This time, a reply rested between its pages.\n\nIt said: I would start by saying hello."}
  ]}
];

let activeFilter = "All";
let currentBook = null;
let currentChapter = 0;
const $ = id => document.getElementById(id);
const grid = $("bookGrid");

function renderBooks(){
  const term = $("searchInput").value.trim().toLowerCase();
  const shown = books.filter(b => (activeFilter==="All" || b.category===activeFilter) &&
    (b.title.toLowerCase().includes(term) || b.author.toLowerCase().includes(term) || b.category.toLowerCase().includes(term)));
  grid.innerHTML = "";
  shown.forEach(book => {
    const card = document.createElement("article");
    card.className = "book-card";
    card.tabIndex = 0;
    card.setAttribute("role","button");
    card.setAttribute("aria-label",`Read ${book.title}`);
    card.innerHTML = `<div class="book-cover" style="background:linear-gradient(145deg,${book.colors[0]},${book.colors[1]})"><div class="cover-inner"><span class="symbol">${book.symbol}</span><strong>${book.title}</strong><small>NOVELVERSE EDITION</small></div></div><div class="book-meta"><span class="category">${book.category}</span><h3>${book.title}</h3><p>By ${book.author} · ${book.chapters.length} chapters</p></div>`;
    card.addEventListener("click",()=>openBook(book));
    card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openBook(book)}});
    grid.appendChild(card);
  });
  $("emptyState").hidden = shown.length>0;
}
function openBook(book){
  currentBook=book; currentChapter=0;
  $("homeView").hidden=true; document.querySelector(".stats-strip").hidden=true;
  document.querySelector(".library-section").hidden=true;
  document.querySelector(".author-banner").hidden=true; document.querySelector(".about-section").hidden=true;
  $("readerView").hidden=false; renderReader(); window.scrollTo({top:0,behavior:"smooth"});
}
function renderReader(){
  const b=currentBook, c=b.chapters[currentChapter];
  $("readerCover").style.background=`linear-gradient(145deg,${b.colors[0]},${b.colors[1]})`;
  $("readerCover").innerHTML=`<div style="height:100%;display:grid;place-items:center;color:#e2c77f;font:24px Georgia">${b.symbol}</div>`;
  $("readerBookTitle").textContent=b.title; $("readerAuthor").textContent=`By ${b.author}`;
  $("chapterBookLabel").textContent=`${b.title.toUpperCase()} · ${b.category.toUpperCase()}`;
  $("chapterTitle").textContent=c.title; $("chapterByline").textContent=`Chapter ${String(currentChapter+1).padStart(2,"0")} · ${b.author}`;
  $("chapterText").textContent=c.text;
  $("chapterList").innerHTML="";
  b.chapters.forEach((ch,i)=>{
    const btn=document.createElement("button");btn.className="chapter-link"+(i===currentChapter?" active":"");
    btn.textContent=`${String(i+1).padStart(2,"0")}  ${ch.title}`;btn.addEventListener("click",()=>{currentChapter=i;renderReader()});$("chapterList").appendChild(btn);
  });
  $("prevChapter").disabled=currentChapter===0;
  $("prevChapter").style.opacity=currentChapter===0?".45":"1";
  $("nextChapter").textContent=currentChapter===b.chapters.length-1?"Back to library →":"Next chapter →";
}
function showLibrary(){
  $("readerView").hidden=true;$("homeView").hidden=false;document.querySelector(".stats-strip").hidden=false;
  document.querySelector(".library-section").hidden=false;document.querySelector(".author-banner").hidden=false;document.querySelector(".about-section").hidden=false;
  window.scrollTo({top:0,behavior:"smooth"});
}
$("searchInput").addEventListener("input",renderBooks);
$("filters").addEventListener("click",e=>{const btn=e.target.closest("button[data-filter]");if(!btn)return;activeFilter=btn.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===btn));renderBooks()});
$("backToLibrary").addEventListener("click",showLibrary);
$("prevChapter").addEventListener("click",()=>{if(currentChapter>0){currentChapter--;renderReader()}});
$("nextChapter").addEventListener("click",()=>{if(currentChapter<currentBook.chapters.length-1){currentChapter++;renderReader()}else{showLibrary()}});
document.querySelectorAll("[data-home]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showLibrary()}));
document.querySelectorAll("[data-library]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showLibrary();document.querySelector(".library-section").scrollIntoView({behavior:"smooth"})}));
document.querySelectorAll("[data-authors]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showLibrary();$("authors").scrollIntoView({behavior:"smooth"})}));
document.querySelectorAll("[data-about]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showLibrary();$("about").scrollIntoView({behavior:"smooth"})}));
document.querySelectorAll("[data-policy]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();$("policyDialog").showModal()}));
$("closePolicy").addEventListener("click",()=>$("policyDialog").close());
$("menuButton").addEventListener("click",()=>document.querySelector(".desktop-nav").classList.toggle("open"));
$("year").textContent=new Date().getFullYear();
renderBooks();
