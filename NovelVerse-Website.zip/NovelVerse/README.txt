NOVELVERSE WEBSITE — STARTER PACKAGE

What is included?
- index.html: website structure
- styles.css: dark premium design
- app.js: book catalogue, search, categories, chapter reader
- This is a working front-end demonstration with fictional sample titles and sample text.

IMPORTANT LIMITATIONS
This package is not yet a live public website. It does not include a secure admin dashboard, database, user accounts, or advertising integration. The sample books and chapters are fictional placeholders. Replace them only with works you own or have written permission to publish and monetize.

CONTACT EMAIL
Before publishing, replace YOUR-EMAIL@example.com in index.html with an email address managed by you and a parent/guardian if needed.

HOW TO VIEW
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html. It opens in your browser.

HOW TO PUT IT ONLINE FOR FREE
A static host such as GitHub Pages can publish these files at no hosting cost. A GitHub account and a few upload steps are required. Ask me to guide you through publishing when you are ready.

ADDING REAL BOOKS
The current sample data lives in app.js. Each book has:
- id
- title
- author
- category
- description
- chapters (each chapter has a title and text)

For a real multi-author site with easy uploads, a content-management system or database-backed admin panel will be needed. Do not collect author manuscripts or personal details until you have a clear privacy process and permission.
